package exception;

public class PhoneException extends Exception {

    public PhoneException(String message) {
        super(message);
    }
}
