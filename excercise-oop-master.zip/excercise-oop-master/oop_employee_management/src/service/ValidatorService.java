package service;

import exception.BirthDayException;
import exception.EmailException;
import exception.FullNameException;
import exception.PhoneException;

import java.time.LocalDate;

public class ValidatorService {

    public static void birthdayCheck(LocalDate birthday) throws BirthDayException {
        // TODO HERE
    }

    public static void phoneCheck(String phone) throws PhoneException {
        // TODO HERE
    }

    public static void emailCheck(String email) throws EmailException {
        // TODO HERE
    }

    public static void nameCheck(String name) throws FullNameException {
        // TODO HERE
    }
}
