public class Main {

    public static void main(String[] args) {
        Date date = new Date(12, 3, 2016);
        System.out.println(date.toString());
        System.out.println(date.isLeapYear());
    }
}
