public class Main {

    public static void main(String[] args) {
        // You can run the exercise for earch package. In each package have Main class.
    }
}
