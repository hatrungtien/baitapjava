package b7;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ManagerTeacher managerTeacher = new ManagerTeacher();
        while (true) {
            // show input for user choise
            // 1 to insert
            // 2 to remove => input id. output boolean
            // 4 get salary => input id. output double
            // 5 exit => return

        }
    }

}
